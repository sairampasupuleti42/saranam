import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-admin-footer',
  templateUrl: './admin-footer.component.html',
  styleUrls: ['./admin-footer.component.css']
})
export class AdminFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
