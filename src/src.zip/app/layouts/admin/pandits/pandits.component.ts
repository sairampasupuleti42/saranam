import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pandits',
  templateUrl: './pandits.component.html',
  styleUrls: ['./pandits.component.css']
})
export class PanditsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
