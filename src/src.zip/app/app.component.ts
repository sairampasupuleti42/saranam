import { Component } from '@angular/core';
declare var $;
@Component({
  selector: 'app-root',
  template: '<router-outlet></router-outlet>',
})

export class AppComponent {
  constructor() {
  }
}
